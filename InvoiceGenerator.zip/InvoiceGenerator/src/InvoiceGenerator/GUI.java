package InvoiceGenerator;

import java.awt.EventQueue;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

//Business Logic 

class InvoiceCalculator {

    /** Calculate total for a single line item */
    public static double calculateItemTotal(int qty, double unitPrice) {
        return qty * unitPrice;
    }

    /** Calculate tax amount (10%) on subtotal */
    public static double calculateTax(double subtotal) {
        return subtotal * 0.10;
    }

    /** Calculate discount amount (5%) on subtotal */
    public static double calculateDiscount(double subtotal) {
        return subtotal * 0.05;
    }

    /** Calculate grand total applying optional tax and discount */
    public static double calculateGrandTotal(double subtotal, boolean applyTax, boolean applyDiscount) {
        double tax      = applyTax      ? calculateTax(subtotal)      : 0;
        double discount = applyDiscount ? calculateDiscount(subtotal) : 0;
        return subtotal + tax - discount;
    }
}

//  Custom Exceptions 

class EmptyItemFieldException extends Exception {
    public EmptyItemFieldException(String msg) { super(msg); }
}

class InvalidItemValueException extends Exception {
    public InvalidItemValueException(String msg) { super(msg); }
}

class EmptyInvoiceInfoException extends Exception {
    public EmptyInvoiceInfoException(String msg) { super(msg); }
}

class NoItemsAddedException extends Exception {
    public NoItemsAddedException(String msg) { super(msg); }
}

class PaymentMethodNotSelectedException extends Exception {
    public PaymentMethodNotSelectedException(String msg) { super(msg); }
}

// GUI (Event Handling)

public class GUI extends JFrame {

    private JPanel contentPane;

    //  Customer / Company Info
    private JTextField txtCustomerName;
    private JTextField txtCompanyName;
    private JTextField txtDate;
    private JTextField txtInvoiceNo;
    private JComboBox<String> comboPaymentMethod;
    private JCheckBox chkTax;
    private JCheckBox chkDiscount;
    private JRadioButton rbPaid;
    private JRadioButton rbUnpaid;
    private ButtonGroup statusGroup;

    //  Item Entry 
    private JTextField txtItemName;
    private JTextField txtQuantity;
    private JTextField txtUnitPrice;

    //  Table 
    private JTable itemTable;
    private DefaultTableModel tableModel;
    private JScrollPane scrollPane;

    //  Summary Labels 
    private JLabel lblSubtotal;
    private JLabel lblTax;
    private JLabel lblDiscount;
    private JLabel lblTotal;

    //  Buttons 
    private JButton btnAddItem;
    private JButton btnRemoveItem;
    private JButton btnGenerateInvoice;
    private JButton btnReset;

    // Menu 
    private JMenuBar menuBar;
    private JMenu menuFile;
    private JMenuItem menuExit;
    private JMenuItem menuAbout;

    private double subtotal = 0;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    GUI frame = new GUI();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public GUI() {
        setTitle("🧾 Invoice Generator");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 50, 700, 720);

        // Menu Bar 
        menuBar = new JMenuBar();
        menuFile = new JMenu("File");
        menuAbout = new JMenuItem("About");
        menuExit  = new JMenuItem("Exit");
        menuAbout.addActionListener(e ->
            JOptionPane.showMessageDialog(this, "Invoice Generator v1.0\nBuilt with Java Swing"));
        menuExit.addActionListener(e -> System.exit(0));
        menuFile.add(menuAbout);
        menuFile.addSeparator();
        menuFile.add(menuExit);
        menuBar.add(menuFile);
        setJMenuBar(menuBar);

        //  Content Pane 
        contentPane = new JPanel();
        contentPane.setBackground(new Color(245, 245, 250));
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        contentPane.setLayout(null);
        setContentPane(contentPane);

     
        //  Company & Customer Info
    
        JPanel pnlInfo = new JPanel();
        pnlInfo.setLayout(null);
        pnlInfo.setBounds(10, 5, 660, 160);
        pnlInfo.setBackground(Color.WHITE);
        pnlInfo.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(63, 81, 181), 2),
            "📋 Invoice Details",
            TitledBorder.LEFT, TitledBorder.TOP,
            new Font("Arial", Font.BOLD, 13), new Color(63, 81, 181)));
        contentPane.add(pnlInfo);

        addLabel(pnlInfo, "Company Name:", 10, 25, Color.DARK_GRAY);
        txtCompanyName = addTextField(pnlInfo, 130, 25, 180);

        addLabel(pnlInfo, "Invoice No:", 330, 25, Color.DARK_GRAY);
        txtInvoiceNo = addTextField(pnlInfo, 430, 25, 120);
        txtInvoiceNo.setText("INV-001");

        addLabel(pnlInfo, "Customer Name:", 10, 60, Color.DARK_GRAY);
        txtCustomerName = addTextField(pnlInfo, 130, 60, 180);

        addLabel(pnlInfo, "Date (dd-MM-yyyy):", 330, 60, Color.DARK_GRAY);
        txtDate = addTextField(pnlInfo, 460, 60, 120);
        txtDate.setText(LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy")));

        addLabel(pnlInfo, "Payment Method:", 10, 95, Color.DARK_GRAY);
        comboPaymentMethod = new JComboBox<>(new String[]{"Select Method", "Cash", "Credit Card", "Bank Transfer", "Cheque"});
        comboPaymentMethod.setBounds(130, 95, 150, 25);
        pnlInfo.add(comboPaymentMethod);

        chkTax = new JCheckBox("Apply Tax (10%)");
        chkTax.setBounds(300, 95, 140, 22);
        chkTax.setBackground(Color.WHITE);
        chkTax.setFont(new Font("Arial", Font.PLAIN, 12));
        pnlInfo.add(chkTax);

        chkDiscount = new JCheckBox("Apply Discount (5%)");
        chkDiscount.setBounds(445, 95, 160, 22);
        chkDiscount.setBackground(Color.WHITE);
        chkDiscount.setFont(new Font("Arial", Font.PLAIN, 12));
        pnlInfo.add(chkDiscount);

        addLabel(pnlInfo, "Status:", 10, 128, Color.DARK_GRAY);
        rbPaid   = new JRadioButton("Paid");
        rbUnpaid = new JRadioButton("Unpaid");
        rbUnpaid.setSelected(true);
        rbPaid.setBounds(80, 126, 65, 22);
        rbUnpaid.setBounds(150, 126, 75, 22);
        rbPaid.setBackground(Color.WHITE);
        rbUnpaid.setBackground(Color.WHITE);
        rbPaid.setFont(new Font("Arial", Font.PLAIN, 12));
        rbUnpaid.setFont(new Font("Arial", Font.PLAIN, 12));
        statusGroup = new ButtonGroup();
        statusGroup.add(rbPaid);
        statusGroup.add(rbUnpaid);
        pnlInfo.add(rbPaid);
        pnlInfo.add(rbUnpaid);

       
        // Add Item
      
        JPanel pnlItem = new JPanel();
        pnlItem.setLayout(null);
        pnlItem.setBounds(10, 175, 660, 80);
        pnlItem.setBackground(Color.WHITE);
        pnlItem.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(63, 81, 181), 2),
            "➕ Add Item",
            TitledBorder.LEFT, TitledBorder.TOP,
            new Font("Arial", Font.BOLD, 13), new Color(63, 81, 181)));
        contentPane.add(pnlItem);

        addLabel(pnlItem, "Item Name:", 10, 28, Color.DARK_GRAY);
        txtItemName = addTextField(pnlItem, 90, 28, 160);

        addLabel(pnlItem, "Quantity:", 265, 28, Color.DARK_GRAY);
        txtQuantity = addTextField(pnlItem, 335, 28, 60);

        addLabel(pnlItem, "Unit Price (Rs):", 410, 28, Color.DARK_GRAY);
        txtUnitPrice = addTextField(pnlItem, 520, 28, 80);

        btnAddItem = new JButton("Add ➕");
        btnAddItem.setBounds(10, 52, 100, 18);
        btnAddItem.setBackground(new Color(63, 81, 181));
        btnAddItem.setForeground(Color.WHITE);
        btnAddItem.setFont(new Font("Arial", Font.BOLD, 11));
        btnAddItem.setFocusPainted(false);
        pnlItem.add(btnAddItem);

        btnRemoveItem = new JButton("Remove ❌");
        btnRemoveItem.setBounds(120, 52, 120, 18);
        btnRemoveItem.setBackground(new Color(211, 47, 47));
        btnRemoveItem.setForeground(Color.WHITE);
        btnRemoveItem.setFont(new Font("Arial", Font.BOLD, 11));
        btnRemoveItem.setFocusPainted(false);
        pnlItem.add(btnRemoveItem);

        
        //  Items Table
   
        JLabel lblItems = new JLabel("📦 Items List:");
        lblItems.setBounds(10, 262, 120, 20);
        lblItems.setFont(new Font("Arial", Font.BOLD, 13));
        lblItems.setForeground(new Color(63, 81, 181));
        contentPane.add(lblItems);

        tableModel = new DefaultTableModel(
            new String[]{"#", "Item Name", "Quantity", "Unit Price (Rs)", "Total (Rs)"}, 0) {
            public boolean isCellEditable(int row, int col) { return false; }
        };

        itemTable = new JTable(tableModel);
        itemTable.setFont(new Font("Arial", Font.PLAIN, 12));
        itemTable.setRowHeight(24);
        itemTable.getTableHeader().setBackground(new Color(63, 81, 181));
        itemTable.getTableHeader().setForeground(Color.WHITE);
        itemTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));
        itemTable.setSelectionBackground(new Color(197, 202, 233));
        itemTable.setGridColor(new Color(200, 200, 200));

        itemTable.getColumnModel().getColumn(0).setPreferredWidth(30);
        itemTable.getColumnModel().getColumn(1).setPreferredWidth(200);
        itemTable.getColumnModel().getColumn(2).setPreferredWidth(70);
        itemTable.getColumnModel().getColumn(3).setPreferredWidth(120);
        itemTable.getColumnModel().getColumn(4).setPreferredWidth(100);

        scrollPane = new JScrollPane(itemTable);
        scrollPane.setBounds(10, 285, 660, 160);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(63, 81, 181)));
        contentPane.add(scrollPane);

       
        
        JPanel pnlSummary = new JPanel();
        pnlSummary.setLayout(null);
        pnlSummary.setBounds(380, 455, 290, 120);
        pnlSummary.setBackground(Color.WHITE);
        pnlSummary.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(63, 81, 181), 2),
            "💰 Summary",
            TitledBorder.LEFT, TitledBorder.TOP,
            new Font("Arial", Font.BOLD, 13), new Color(63, 81, 181)));
        contentPane.add(pnlSummary);

        lblSubtotal = makeSummaryLabel(pnlSummary, "Subtotal:    Rs. 0.00",    10, 25);
        lblTax      = makeSummaryLabel(pnlSummary, "Tax (10%):   Rs. 0.00",    10, 48);
        lblDiscount = makeSummaryLabel(pnlSummary, "Discount (5%): Rs. 0.00",  10, 71);

        lblTotal = new JLabel("TOTAL:       Rs. 0.00");
        lblTotal.setBounds(10, 94, 270, 20);
        lblTotal.setFont(new Font("Arial", Font.BOLD, 14));
        lblTotal.setForeground(new Color(63, 81, 181));
        pnlSummary.add(lblTotal);

       
        //  Action Buttons
    
        btnGenerateInvoice = new JButton("🧾 Generate Invoice");
        btnGenerateInvoice.setBounds(10, 590, 200, 40);
        btnGenerateInvoice.setBackground(new Color(30, 150, 80));
        btnGenerateInvoice.setForeground(Color.WHITE);
        btnGenerateInvoice.setFont(new Font("Arial", Font.BOLD, 14));
        btnGenerateInvoice.setFocusPainted(false);
        contentPane.add(btnGenerateInvoice);

        btnReset = new JButton("🔄 Reset All");
        btnReset.setBounds(225, 590, 150, 40);
        btnReset.setBackground(new Color(120, 120, 120));
        btnReset.setForeground(Color.WHITE);
        btnReset.setFont(new Font("Arial", Font.BOLD, 14));
        btnReset.setFocusPainted(false);
        contentPane.add(btnReset);

    
        // EVENT HANDLERS
        
        // Add Item
        btnAddItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    String itemName = txtItemName.getText().trim();
                    String qtyStr   = txtQuantity.getText().trim();
                    String priceStr = txtUnitPrice.getText().trim();

                    if (itemName.isEmpty() || qtyStr.isEmpty() || priceStr.isEmpty()) {
                        throw new EmptyItemFieldException("Item Name, Quantity and Price are required!");
                    }

                    // NumberFormatException handled below
                    int    qty   = Integer.parseInt(qtyStr);
                    double price = Double.parseDouble(priceStr);

                    if (qty <= 0)   throw new InvalidItemValueException("Quantity must be greater than 0!");
                    if (price <= 0) throw new InvalidItemValueException("Price must be greater than 0!");

                    //  Business logic
                    double total  = InvoiceCalculator.calculateItemTotal(qty, price);
                    int    rowNum = tableModel.getRowCount() + 1;

                    tableModel.addRow(new Object[]{
                        rowNum,
                        itemName,
                        qty,
                        String.format("%.2f", price),
                        String.format("%.2f", total)
                    });

                    subtotal += total;
                    updateSummary();

                    txtItemName.setText("");
                    txtQuantity.setText("");
                    txtUnitPrice.setText("");

                } catch (EmptyItemFieldException | InvalidItemValueException ex) {
                    JOptionPane.showMessageDialog(null, "⚠ " + ex.getMessage(), "Input Error", JOptionPane.ERROR_MESSAGE);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "⚠ Quantity and Price must be valid numbers!", "Number Error", JOptionPane.ERROR_MESSAGE);
                } finally {
                    txtItemName.requestFocus();
                }
            }
        });

        // Remove Item
        btnRemoveItem.addActionListener(e -> {
            int selectedRow = itemTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(null, "⚠ Please select a row to remove!", "No Selection", JOptionPane.WARNING_MESSAGE);
                return;
            }
            String totalStr = tableModel.getValueAt(selectedRow, 4).toString();
            subtotal -= Double.parseDouble(totalStr);
            tableModel.removeRow(selectedRow);

        
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                tableModel.setValueAt(i + 1, i, 0);
            }
            updateSummary();
        });

        // Generate Invoice
        btnGenerateInvoice.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    String customer = txtCustomerName.getText().trim();
                    String company  = txtCompanyName.getText().trim();
                    String date     = txtDate.getText().trim();
                    String invNo    = txtInvoiceNo.getText().trim();

                    if (customer.isEmpty() || company.isEmpty() || date.isEmpty() || invNo.isEmpty()) {
                        throw new EmptyInvoiceInfoException("Company Name, Customer Name, Date and Invoice No are required!");
                    }

                    if (tableModel.getRowCount() == 0) {
                        throw new NoItemsAddedException("Please add at least one item to generate invoice!");
                    }

                    if (comboPaymentMethod.getSelectedIndex() == 0) {
                        throw new PaymentMethodNotSelectedException("Please select a payment method!");
                    }

                    // Date format validation
                    DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd-MM-yyyy");
                    LocalDate.parse(date, fmt);

                    //calculations
                    double taxAmt      = InvoiceCalculator.calculateTax(subtotal);
                    double discountAmt = InvoiceCalculator.calculateDiscount(subtotal);
                    double grandTotal  = InvoiceCalculator.calculateGrandTotal(
                                            subtotal,
                                            chkTax.isSelected(),
                                            chkDiscount.isSelected());

                    // Adjust display values based on checkbox state
                    double displayTax      = chkTax.isSelected()      ? taxAmt      : 0;
                    double displayDiscount = chkDiscount.isSelected()  ? discountAmt : 0;
                    String status          = rbPaid.isSelected() ? "✅ PAID" : "❌ UNPAID";

                    // Build invoice string
                    StringBuilder sb = new StringBuilder();
                    sb.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
                    sb.append("          🧾 INVOICE\n");
                    sb.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
                    sb.append("Company   : ").append(company).append("\n");
                    sb.append("Invoice No: ").append(invNo).append("\n");
                    sb.append("Date      : ").append(date).append("\n");
                    sb.append("Customer  : ").append(customer).append("\n");
                    sb.append("Payment   : ").append(comboPaymentMethod.getSelectedItem()).append("\n");
                    sb.append("Status    : ").append(status).append("\n");
                    sb.append("────────────────────────────────────\n");
                    sb.append(String.format("%-3s %-18s %5s %10s %10s\n", "#", "Item", "Qty", "Price", "Total"));
                    sb.append("────────────────────────────────────\n");

                    for (int i = 0; i < tableModel.getRowCount(); i++) {
                        sb.append(String.format("%-3s %-18s %5s %10s %10s\n",
                            tableModel.getValueAt(i, 0),
                            tableModel.getValueAt(i, 1),
                            tableModel.getValueAt(i, 2),
                            tableModel.getValueAt(i, 3),
                            tableModel.getValueAt(i, 4)));
                    }

                    sb.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
                    sb.append(String.format("Subtotal  : Rs. %10.2f\n", subtotal));
                    sb.append(String.format("Tax (10%%) : Rs. %10.2f\n", displayTax));
                    sb.append(String.format("Discount  : Rs. %10.2f\n", displayDiscount));
                    sb.append("────────────────────────────────────\n");
                    sb.append(String.format("GRAND TOTAL: Rs. %9.2f\n", grandTotal));
                    sb.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
                    sb.append("     Thank you for your business!\n");
                    sb.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");

                    JTextArea area = new JTextArea(sb.toString());
                    area.setFont(new Font("Monospaced", Font.PLAIN, 12));
                    area.setEditable(false);
                    area.setBackground(new Color(250, 250, 250));
                    JScrollPane sp = new JScrollPane(area);
                    sp.setPreferredSize(new java.awt.Dimension(440, 380));

                    JOptionPane.showMessageDialog(null, sp, "🧾 Invoice Generated!", JOptionPane.PLAIN_MESSAGE);

                } catch (EmptyInvoiceInfoException | NoItemsAddedException | PaymentMethodNotSelectedException ex) {
                    JOptionPane.showMessageDialog(null, "⚠ " + ex.getMessage(), "Validation Error", JOptionPane.ERROR_MESSAGE);
                } catch (DateTimeParseException ex) {
                    JOptionPane.showMessageDialog(null, "⚠ Invalid date format! Use dd-MM-yyyy (e.g. 26-05-2026)", "Date Error", JOptionPane.ERROR_MESSAGE);
                } finally {
                    JOptionPane.showMessageDialog(null, "ℹ Operation Completed", "Info", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        // Reset All
        btnReset.addActionListener(e -> {
            txtCustomerName.setText("");
            txtCompanyName.setText("");
            txtInvoiceNo.setText("INV-001");
            txtDate.setText(LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy")));
            txtItemName.setText("");
            txtQuantity.setText("");
            txtUnitPrice.setText("");
            comboPaymentMethod.setSelectedIndex(0);
            chkTax.setSelected(false);
            chkDiscount.setSelected(false);
            rbUnpaid.setSelected(true);
            tableModel.setRowCount(0);
            subtotal = 0;
            updateSummary();
        });

       
        chkTax.addActionListener(e -> updateSummary());
        chkDiscount.addActionListener(e -> updateSummary());
    }

    // summary panel using InvoiceCalculator
    private void updateSummary() {
        double taxAmt      = InvoiceCalculator.calculateTax(subtotal);
        double discountAmt = InvoiceCalculator.calculateDiscount(subtotal);
        double grandTotal  = InvoiceCalculator.calculateGrandTotal(
                                subtotal,
                                chkTax.isSelected(),
                                chkDiscount.isSelected());

        lblSubtotal.setText(String.format("Subtotal:      Rs. %.2f", subtotal));
        lblTax.setText(String.format("Tax (10%%):     Rs. %.2f", chkTax.isSelected() ? taxAmt : 0));
        lblDiscount.setText(String.format("Discount (5%%): Rs. %.2f", chkDiscount.isSelected() ? discountAmt : 0));
        lblTotal.setText(String.format("TOTAL:         Rs. %.2f", grandTotal));
    }

    // label
    private void addLabel(JPanel p, String text, int x, int y, Color c) {
        JLabel lbl = new JLabel(text);
        lbl.setBounds(x, y, 130, 20);
        lbl.setFont(new Font("Arial", Font.BOLD, 12));
        lbl.setForeground(c);
        p.add(lbl);
    }

    // text field
    private JTextField addTextField(JPanel p, int x, int y, int w) {
        JTextField tf = new JTextField();
        tf.setBounds(x, y, w, 22);
        tf.setFont(new Font("Arial", Font.PLAIN, 12));
        p.add(tf);
        return tf;
    }

  
    private JLabel makeSummaryLabel(JPanel p, String text, int x, int y) {
        JLabel lbl = new JLabel(text);
        lbl.setBounds(x, y, 270, 18);
        lbl.setFont(new Font("Arial", Font.PLAIN, 12));
        lbl.setForeground(Color.DARK_GRAY);
        p.add(lbl);
        return lbl;
    }
}